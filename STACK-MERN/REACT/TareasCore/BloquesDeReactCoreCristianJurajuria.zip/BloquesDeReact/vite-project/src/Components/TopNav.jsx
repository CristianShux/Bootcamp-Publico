import styles from './../Css/TopNav.module.css'

const TopNav=()=>{
    return <div className={styles.topNav}></div>
}

export default TopNav;