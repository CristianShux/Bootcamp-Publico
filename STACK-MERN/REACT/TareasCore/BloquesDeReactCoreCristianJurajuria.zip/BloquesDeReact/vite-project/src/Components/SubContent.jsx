import styles from './../Css/SubContent.module.css'

const SubContent=()=>{
    return <div className={styles.subContent}></div>
}

export default SubContent;