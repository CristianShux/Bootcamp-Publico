import styles from './../Css/Advertisement.module.css'
const Advertisement=()=>{
    return <div className={styles.advertisement}></div>
}

export default Advertisement;