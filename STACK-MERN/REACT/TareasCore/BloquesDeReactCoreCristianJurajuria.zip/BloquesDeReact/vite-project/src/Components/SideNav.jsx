import styles from './../Css/SideNav.module.css'

const SideNav=()=>{
    return <div className={styles.sideNav}></div>
}

export default SideNav;