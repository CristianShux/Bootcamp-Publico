import "./App.css";

function App() {
  return (
    <>
      <header></header>
      <main>
        <h1>¡Bienvenido a mi aplicación de React!</h1>
        <h2>Lista de cosas por hacer:</h2>
        <ul>
          <li>Aprender React</li>
          <li>Practicar con Vite</li>
          <li>Construir proyectos increíbles</li>
        </ul>
      </main>
      <footer></footer>
    </>
  );
}

export default App;
